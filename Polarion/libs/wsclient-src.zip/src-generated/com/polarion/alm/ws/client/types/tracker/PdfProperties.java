/**
 * PdfProperties.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.polarion.alm.ws.client.types.tracker;

public class PdfProperties  implements java.io.Serializable {
    private java.lang.String paperSize;

    private java.lang.String orientation;

    private boolean fitToPageWidth;

    private boolean generateBookmarks;

    private boolean includeHeaderFooter;

    public PdfProperties() {
    }

    public PdfProperties(
           java.lang.String paperSize,
           java.lang.String orientation,
           boolean fitToPageWidth,
           boolean generateBookmarks,
           boolean includeHeaderFooter) {
           this.paperSize = paperSize;
           this.orientation = orientation;
           this.fitToPageWidth = fitToPageWidth;
           this.generateBookmarks = generateBookmarks;
           this.includeHeaderFooter = includeHeaderFooter;
    }


    /**
     * Gets the paperSize value for this PdfProperties.
     * 
     * @return paperSize
     */
    public java.lang.String getPaperSize() {
        return paperSize;
    }


    /**
     * Sets the paperSize value for this PdfProperties.
     * 
     * @param paperSize
     */
    public void setPaperSize(java.lang.String paperSize) {
        this.paperSize = paperSize;
    }


    /**
     * Gets the orientation value for this PdfProperties.
     * 
     * @return orientation
     */
    public java.lang.String getOrientation() {
        return orientation;
    }


    /**
     * Sets the orientation value for this PdfProperties.
     * 
     * @param orientation
     */
    public void setOrientation(java.lang.String orientation) {
        this.orientation = orientation;
    }


    /**
     * Gets the fitToPageWidth value for this PdfProperties.
     * 
     * @return fitToPageWidth
     */
    public boolean isFitToPageWidth() {
        return fitToPageWidth;
    }


    /**
     * Sets the fitToPageWidth value for this PdfProperties.
     * 
     * @param fitToPageWidth
     */
    public void setFitToPageWidth(boolean fitToPageWidth) {
        this.fitToPageWidth = fitToPageWidth;
    }


    /**
     * Gets the generateBookmarks value for this PdfProperties.
     * 
     * @return generateBookmarks
     */
    public boolean isGenerateBookmarks() {
        return generateBookmarks;
    }


    /**
     * Sets the generateBookmarks value for this PdfProperties.
     * 
     * @param generateBookmarks
     */
    public void setGenerateBookmarks(boolean generateBookmarks) {
        this.generateBookmarks = generateBookmarks;
    }


    /**
     * Gets the includeHeaderFooter value for this PdfProperties.
     * 
     * @return includeHeaderFooter
     */
    public boolean isIncludeHeaderFooter() {
        return includeHeaderFooter;
    }


    /**
     * Sets the includeHeaderFooter value for this PdfProperties.
     * 
     * @param includeHeaderFooter
     */
    public void setIncludeHeaderFooter(boolean includeHeaderFooter) {
        this.includeHeaderFooter = includeHeaderFooter;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PdfProperties)) return false;
        PdfProperties other = (PdfProperties) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.paperSize==null && other.getPaperSize()==null) || 
             (this.paperSize!=null &&
              this.paperSize.equals(other.getPaperSize()))) &&
            ((this.orientation==null && other.getOrientation()==null) || 
             (this.orientation!=null &&
              this.orientation.equals(other.getOrientation()))) &&
            this.fitToPageWidth == other.isFitToPageWidth() &&
            this.generateBookmarks == other.isGenerateBookmarks() &&
            this.includeHeaderFooter == other.isIncludeHeaderFooter();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPaperSize() != null) {
            _hashCode += getPaperSize().hashCode();
        }
        if (getOrientation() != null) {
            _hashCode += getOrientation().hashCode();
        }
        _hashCode += (isFitToPageWidth() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isGenerateBookmarks() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIncludeHeaderFooter() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PdfProperties.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.polarion.com/TrackerWebService-types", "PdfProperties"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paperSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.polarion.com/TrackerWebService-types", "paperSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orientation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.polarion.com/TrackerWebService-types", "orientation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fitToPageWidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.polarion.com/TrackerWebService-types", "fitToPageWidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("generateBookmarks");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.polarion.com/TrackerWebService-types", "generateBookmarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeHeaderFooter");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.polarion.com/TrackerWebService-types", "includeHeaderFooter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  com.polarion.alm.ws.client.internal.encoding.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
